/* SPDX-License-Identifier: MIT */
// Zotero loads pane scripts in a sandbox, whereas inline XUL handlers execute
// in the preferences window. Export the controller explicitly to that window.
window.KeepReaderReadyPreferences = {
  init(win) {
    const doc = win.document;
    const root = doc.getElementById("keep-reader-ready-pane");
    if (!root || root.hasAttribute("data-initialized")) return;
    root.setAttribute("data-initialized", "true");
    const api = Zotero.KeepReaderReady;
    const enabled = doc.getElementById("keep-reader-ready-enabled");
    const tabs = doc.getElementById("keep-reader-ready-tabs");
    const cache = doc.getElementById("keep-reader-ready-cache");
    const preload = doc.getElementById("keep-reader-ready-preload");
    const apply = doc.getElementById("keep-reader-ready-reapply");
    const render = () => {
      if (!root.isConnected) return;
      const status = api?.getStatus();
      if (!status) {
        doc.getElementById("keep-reader-ready-status").textContent = "插件未运行，请在“工具 → 插件”中启用。";
        enabled.disabled = tabs.disabled = cache.disabled = preload.disabled = apply.disabled = true;
        return;
      }
      enabled.checked = status.enabled;
      tabs.checked = status.keepTabsLoaded;
      cache.checked = status.retainBrowsedPages;
      preload.checked = status.preloadWholePDF;
      tabs.disabled = cache.disabled = preload.disabled = apply.disabled = !status.enabled;
      doc.getElementById("keep-reader-ready-status").textContent = status.enabled
        ? `已启用 · 已保护 ${status.protectedReaders} / ${status.loaded} 个已加载 PDF 阅读器`
        : "已关闭 · 使用 Zotero 原有的缓存清理和标签页卸载规则";
      doc.getElementById("keep-reader-ready-version").textContent =
        `当前 Zotero：${status.version} · 标签页卸载保护：${status.enabled && status.keepTabsLoaded ? status.protectedWindows + " 个主窗口" : "关闭"}`;
      doc.getElementById("keep-reader-ready-cache-status").textContent =
        !status.enabled ? "已浏览页面缓存保留：关闭" :
        !status.retainBrowsedPages ? (status.preloadWholePDF ? "页面缓存：随整篇预加载保留" : "已浏览页面缓存保留：关闭") :
          `已浏览页面缓存保留：已缓存 ${status.cache.ready} / ${status.cache.total} 页` +
          (status.cache.waiting ? ` · ${status.cache.waiting} 篇正在初始化` : "");
      doc.getElementById("keep-reader-ready-preload-status").textContent =
        !status.enabled || !status.preloadWholePDF ? "整篇 PDF 预加载：关闭" :
          `整篇 PDF 预加载：已渲染 ${status.preload.ready} / ${status.preload.total} 页` +
          (status.preload.total && status.preload.ready === status.preload.total && !status.preload.waiting && !status.preload.unavailable ? " · 已完成" : "") +
          (status.preload.waiting ? ` · ${status.preload.waiting} 篇正在初始化` : "") +
          (status.preload.failed ? ` · ${status.preload.failed} 页加载失败` : "") +
          (status.preload.unavailable ? ` · ${status.preload.unavailable} 篇启动失败，详见检查结果` : "");
      const errors = doc.getElementById("keep-reader-ready-errors");
      errors.hidden = !status.errors.length;
      errors.textContent = status.errors.length ? "检查结果：" + status.errors.join("；") : "";
    };
    enabled.addEventListener("command", () => api.setOption("enabled", enabled.checked));
    tabs.addEventListener("command", () => api.setOption("keepTabsLoaded", tabs.checked));
    cache.addEventListener("command", () => api.setOption("retainBrowsedPages", cache.checked));
    preload.addEventListener("command", () => api.setOption("preloadWholePDF", preload.checked));
    apply.addEventListener("command", async () => {
      await api.applyToAll();
      render();
    });
    const unsubscribe = api?.subscribe(render);
    win.addEventListener("unload", () => unsubscribe?.(), { once: true });
    render();
  }
};
